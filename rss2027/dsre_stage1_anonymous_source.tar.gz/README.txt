Anonymous Stage 1 source

Build the six-page paper from this directory:
  tectonic --untrusted --keep-logs dsre_stage1.tex

All required assets are included; no external supplement is needed to read the paper.
The original drawing and aggregate figure data are provided. To regenerate media
in an environment containing matplotlib and numpy:
  python figure_source.py --data stage1_evidence/figure_data.json --output stage1_evidence

The table contains observed outcomes; calibration bounds appear separately.
This source bundle contains no test-parent identifiers or internal research ledgers.
