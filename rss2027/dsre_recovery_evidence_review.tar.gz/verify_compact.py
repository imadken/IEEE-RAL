"""Verify released decisions, calibration and paired estimates without raw physics.
Run from the repository with PYTHONPATH=src; pass the extracted packet directory.
Full physics verification additionally requires the retained local raw traces.
"""
import gzip,json,sys
from pathlib import Path
from collections import Counter
import numpy as np
from dual_rec.dsre.operational import METHODS,OperationalRouter,PolicyInput,calibrate_records,gated_action
from dual_rec.dsre.calibration import upper_bound
root=Path(sys.argv[1]);data=root/'data';results=root/'results'
def j(p):return json.loads(p.read_text())
def lines(p):
 with gzip.open(p,'rt') as f:return [json.loads(s) for s in f]
with gzip.open(data/'frozen_routers.json.gz','rt') as f:frozen=json.load(f)
router=OperationalRouter(frozen);counts=Counter();new=[];routing=0
for parent in lines(data/'calibration_parents.jsonl.gz'):
 proposals=[]
 for condition in parent['conditions']:
  proposed=router.route(PolicyInput.model_validate(condition['packet']));proposals.append(proposed)
  for m in METHODS:assert proposed[m]['action']==condition['all_actions'][m]['proposal'];routing+=1
 admitted=[m for m in METHODS if counts[m]<112 and any(p[m]['action']=='recover' for p in proposals)]
 assert admitted==parent['admitted_methods']
 for m in admitted:
  for i,c in enumerate(parent['conditions']):
   if proposals[i][m]['action']=='recover':new.append({'method':m,'task':'PickCube-v1','action':'recover','group':parent['group'],'unacceptable':not c['outcomes']['recover']})
 counts.update(admitted)
old=lines(data/'original_calibration_assignments.jsonl.gz');bounds=calibrate_records(old+new);cal=j(results/'calibration_decision.json')['strata']
for key,value in cal.items():
 calculated=bounds[key]
 assert (value['assigned_parents'],value['error_parents'])==(calculated['assigned_parents'],calculated['error_parents'])
 assert abs(value['upper']-calculated['upper'])<1e-10
 if key.endswith('|PickCube-v1|recover'):
  m=key.split('|')[0];rs=[r for r in new if r['method']==m];g={r['group'] for r in rs};e={r['group'] for r in rs if r['unacceptable']};fresh=upper_bound(len(e),len(g),.05/68)
  assert abs(value['new_upper']-fresh)<1e-10
  assert value['enabled']==bool(len(g)==112 and value['upper']<=.1 and fresh<=.1)
 else:assert value['enabled']==calculated['enabled']
parents=lines(data/'test_parents.jsonl.gz');rows=[]
for p in parents:
 for c in p['conditions']:
  proposed=router.route(PolicyInput.model_validate(c['packet']))
  for m in METHODS:
   assert proposed[m]['action']==c['all_actions'][m]['proposal'];assert gated_action(m,'PickCube-v1',proposed[m]['action'],cal)==c['all_actions'][m]['gated'];routing+=1
  rows.append((p,c))
a=j(results/'test_analysis.json');fields={};groups=sorted({p['group'] for p,c in rows});pi=np.array([groups.index(p['group']) for p,c in rows]);n=len(groups)
truth=np.array([[c['outcomes'][x] for x in ('continue','recover')] for p,c in rows]);initial=np.array([c['initial_success'] for p,c in rows]);required=~initial&~truth[:,0]&truth[:,1]
for mode,field in [('proposal','proposal'),('calibrated','gated')]:
 for m in METHODS:
  action=np.array([{None:-1,'continue':0,'recover':1}[c['all_actions'][m][field]] for p,c in rows]);used=action>=0;good=used&truth[np.arange(len(rows)),np.maximum(action,0)];bad=used&~good;req=(action==1)&required
  tab=a['tables'][f'PickCube-v1|{m}|{mode}|clean|all']
  expected={'successful':int(good.sum()),'unacceptable':int(bad.sum()),'deferred':int((~used).sum()),'required_recovery_success':int(req.sum())}
  for k,v in expected.items():assert tab[k]==v
  fields[m,mode]={'successful':good.astype(int),'unacceptable':bad.astype(int),'recommended':used.astype(int),'required_recovery_success':req.astype(int)}
rng=np.random.Generator(np.random.PCG64(2026111501));weights=np.array([np.bincount(x,minlength=n) for x in rng.integers(n,size=(4000,n))]);den=np.bincount(pi,minlength=n);checks=0
for (m,mode),values in fields.items():
 for field in values:
  delta=fields['DSRE_risk',mode][field]-values[field];v=np.bincount(pi,weights=delta,minlength=n);sample=(weights@v)/(weights@den);ci=np.percentile(sample,[2.5,97.5]);expected=a['paired_risk_minus_baselines'][m+'|'+mode][field]
  assert abs(expected['estimate']-delta.mean())<1e-12;assert np.allclose(ci,[expected['lower'],expected['upper']],rtol=0,atol=1e-12);checks+=1
print(json.dumps({'verified':True,'routing_labels':routing,'calibration_strata':len(cal),'test_parents':n,'test_checkpoints':len(rows),'failed_start_recover_only':int(required.sum()),'paired_intervals':checks,'scope':'Numerical/routing reproduction. Full raw-physics verification uses the local evidence root.'},indent=2))
