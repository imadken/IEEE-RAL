# DSRE recovery evidence review packet

This packet contains the frozen models, all calibration and test parent manifests,
minimal actual outcomes and sealed decisions, exact results, independent audits,
source versions and the six-page Stage1 paper. Raw state/contact/controller traces
and execution logs are preserved in the workstation evidence root and excluded
from this compact packet. The public numerical verifier checks routing, all risk
strata, point counts and paired intervals. Physics audit reports bind retained raw
files; full raw-state verification requires those files at the recorded paths.

From the project repository with its existing uv environment:

    UV_CACHE_DIR=/tmp/dual-rec-uv-cache PYTHONPATH=src uv run --no-sync python /path/to/extracted/verify_compact.py /path/to/extracted

Scientific scope is clean seeded simulation, a fixed Boolean interface and two
fixed skills. STOP is selective-autonomy deferral, not a measured physical hold.
Ordinary risk rules equal DSRE; unique method superiority is not established.
No conference submission was performed. This named public repository can reveal
authorship and must not be linked from the blind paper.
