# Dual-obligation study: nearest work and scientific gate

## One-page nearest-work comparison, verified before new outcomes

| Primary work | Established mechanism | Boundary for this study |
|---|---|---|
| [RESCUE, arXiv:2610.13516v1](https://arxiv.org/html/2610.13516), 2026 preprint, §§III–V | Matched robot-policy-state interventions distinguish within-attempt success from cost-to-completion; replay fidelity precedes interpreting counterfactual branches. Recovery value depends on intervention, execution model and budget. | Paired evaluation, rescue/harm accounting, action-relative value and replay qualification are established. This follow-up tests which of two explicitly named binary obligations can be independently certified on the same observable proposal. It adds neither a recovery controller nor RESCUE's renewal-cost model or stochastic branch estimator. |
| [Khan, Poupart & Black, ICAPS2009](https://cs.uwaterloo.ca/~ppoupart/publications/explaining-mdps/ICAPS09OKhan.pdf) | Minimal sufficient explanation templates justify factored-MDP policy choices relative to their decision model. | Minimal decision explanations are established. DSRE's existing finite-table literal certificates and witnesses are retained, not reinvented. A population non-degradation label does not become a newly minimized sufficient explanation. |
| [Wu et al., DISCRET, ICML2024](https://proceedings.mlr.press/v235/wu24n.html) | Faithful logical explanations query similar subgroups for individual treatment-effect estimation, with learned rule synthesis. | Outcome-aware subgroup rules are a strong methodological precedent. We neither reproduce its learned synthesizer nor claim that rules grounded in outcomes are new. Exact B7 identity must retain equal credit. |
| [Petrik, Chow & Ghavamzadeh, NeurIPS2016](https://arxiv.org/abs/1607.03842) | Safe policy improvement minimizes robust baseline regret under an inaccurate dynamics model with accuracy assumptions. | Comparing an intervention with a baseline is established. Our parent-conditional binary degradation event is narrower than a long-horizon policy-performance guarantee, particularly with abstention and unmeasured intervention costs. No new regret optimizer or deployment guarantee is claimed. |
| [Geifman & El-Yaniv, NeurIPS2017](https://papers.neurips.cc/paper_files/paper/2017/hash/4a8423d5e91fda00bb7e46540e2b0cf1-Abstract.html) | Selective classification controls accepted risk by rejecting instances and trading coverage for risk. | Risk refusal, holdout calibration and risk–coverage accounting are established. Here the accepted error event is stated explicitly and conditions remain clustered by seed parent. Changing the named event cannot silently redefine task success. |

The binary identity `failure = harm OR neither-success` is elementary.
Counterfactual outcomes, task-relative regret, ordinary minimum rules,
mathematical minimization and Bonferroni/Clopper–Pearson control are not claimed
as inventions. This literature comparison supports a narrow experimental
question about an existing evidence contract's obligation semantics; it does
not establish an absence of closer work or standalone algorithmic novelty.

## Frozen assessment criteria

The fresh result must show whether non-degradation can support genuinely useful
recovery proposals while absolute success remains unqualified, and must expose
futile attempts and harms. A positive label alone is not a substantive distinct
algorithm. If the outcome is reproduced by B7, that is an exact equivalence; if
CART ties the operational frontier, no method advantage is claimed. Different
candidate-assignment frequencies can change statistical support and are not an
inherent controller or optimization advantage. A constant policy would further
restrict the interpretation. The results and final judgment will be appended
only after independent fresh-data verification.

No manuscript or conference-readiness judgment is part of this assignment.
After this finite follow-up, further objectives, features, faults, controllers
or optimizer experiments require supervisor review.
